package com.hkucs.cookbook.activities.main.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.flexbox.FlexboxLayoutManager;

import com.hkucs.cookbook.R;

import java.util.ArrayList;
import java.util.List;

public class RecipeCategoryAdapter extends RecyclerView.Adapter<RecipeCategoryAdapter.ViewHolder> {
    private final Context context;
    private final List<RecipeCategory> recipeCategories;

    public RecipeCategoryAdapter(Context context) {
        this.context = context;
        recipeCategories = initCategories();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(
                R.layout.main_recipe_category_item,
                viewGroup,
                false
        );
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int idx) {
        final RecipeCategory recipeCategory = recipeCategories.get(idx);
        viewHolder.textView.setText(recipeCategory.name);
        viewHolder.imageView.setImageDrawable(context.getDrawable(R.drawable.recipe_category_temp));
    }

    @Override
    public int getItemCount() {
        return recipeCategories.size();
    }

    private List<RecipeCategory> initCategories() {
        final List<RecipeCategory> recipeCategories = new ArrayList<>();
        final String[] recipeCategoryNames = context.getResources().getStringArray(R.array.recipe_categories);
        for (String recipeCategoryName : recipeCategoryNames) {
            recipeCategories.add(new RecipeCategory(recipeCategoryName, R.drawable.recipe_category_temp));
        }
        return recipeCategories;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textView;
        private final ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.main_recipe_category_item_image_view);
            textView = itemView.findViewById(R.id.main_recipe_category_item_text_view);
        }

        public TextView getTextView() {
            return textView;
        }

        public ImageView getImageView() {
            return imageView;
        }
    }

    class RecipeCategory {
        private final String name;
        private final int drawableId;

        public RecipeCategory(String name, int drawableId) {
            this.name = name;
            this.drawableId = drawableId;
        }

        public String getName() {
            return name;
        }

        public int getDrawableId() {
            return drawableId;
        }
    }
}
